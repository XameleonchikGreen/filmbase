An educational project is written using `django` and `python` with
UML diagram.

![Filmbase models](docs/filmbase_models.png)